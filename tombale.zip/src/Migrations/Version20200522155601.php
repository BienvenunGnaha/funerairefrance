<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200522155601 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE faq (id INT AUTO_INCREMENT NOT NULL, quiz VARCHAR(255) NOT NULL, answer LONGTEXT NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME DEFAULT NULL, display_order INT DEFAULT NULL, status VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE newletter (id INT AUTO_INCREMENT NOT NULL, email VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE payment_method (id INT AUTO_INCREMENT NOT NULL, user_id_id INT DEFAULT NULL, type_payment VARCHAR(255) NOT NULL, pay_id VARCHAR(255) NOT NULL, INDEX IDX_7B61A1F69D86650F (user_id_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE payment_method ADD CONSTRAINT FK_7B61A1F69D86650F FOREIGN KEY (user_id_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE category ADD name VARCHAR(255) NOT NULL, ADD display_order INT DEFAULT NULL, ADD created_at DATETIME NOT NULL, ADD updated_at DATETIME DEFAULT NULL, ADD is_displayed_in_menu TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE page ADD display_order INT DEFAULT NULL, ADD status TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE subcategory ADD cat_id_id INT DEFAULT NULL, ADD name VARCHAR(255) NOT NULL, ADD display_order INT DEFAULT NULL, ADD created_at DATETIME NOT NULL, ADD updated_at DATETIME DEFAULT NULL, ADD is_displayed_in_menu TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE subcategory ADD CONSTRAINT FK_DDCA448C33F2EBA FOREIGN KEY (cat_id_id) REFERENCES category (id)');
        $this->addSql('CREATE INDEX IDX_DDCA448C33F2EBA ON subcategory (cat_id_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE faq');
        $this->addSql('DROP TABLE newletter');
        $this->addSql('DROP TABLE payment_method');
        $this->addSql('ALTER TABLE category DROP name, DROP display_order, DROP created_at, DROP updated_at, DROP is_displayed_in_menu');
        $this->addSql('ALTER TABLE page DROP display_order, DROP status');
        $this->addSql('ALTER TABLE subcategory DROP FOREIGN KEY FK_DDCA448C33F2EBA');
        $this->addSql('DROP INDEX IDX_DDCA448C33F2EBA ON subcategory');
        $this->addSql('ALTER TABLE subcategory DROP cat_id_id, DROP name, DROP display_order, DROP created_at, DROP updated_at, DROP is_displayed_in_menu');
    }
}
