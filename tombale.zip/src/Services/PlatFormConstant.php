<?php


namespace App\Services;


final class PlatFormConstant
{
    const SSL_PKEY_PASSPHRASSE = 'bien97venuBatonRoueCasséYann@';
    const PS_TEST_SECRET_KEY = 'sk_test_0af2d49bbb4c4f9a3f60da3c52701a34540741d4';
    const PS_TEST_PUBLIC_KEY = 'pk_test_03028279fa799e5c9544abe01460308274cc015d';
    const STRIPE_TEST_SECRET_KEY = '	sk_test_b39PI9YvbQr7PykEFmmbMTmC';
    const STRIPE_TEST_PUBLIC_KEY = 'pk_test_6J0PXckjwHH1A6w5cU6LE6L3';
    const PS_API_URL = 'https://api.paystack.co';
}
