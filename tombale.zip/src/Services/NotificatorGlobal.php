<?php


namespace App\Services;


class NotificatorGlobal
{

}