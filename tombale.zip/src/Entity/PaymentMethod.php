<?php

namespace App\Entity;

use App\Repository\PaymentMethodRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PaymentMethodRepository::class)
 */
class PaymentMethod
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="paymentMethods")
     */
    private $user_id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $typePayment;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $payId;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUserId(): ?User
    {
        return $this->user_id;
    }

    public function setUserId(?User $user_id): self
    {
        $this->user_id = $user_id;

        return $this;
    }

    public function getTypePayment(): ?string
    {
        return $this->typePayment;
    }

    public function setTypePayment(string $typePayment): self
    {
        $this->typePayment = $typePayment;

        return $this;
    }

    public function getPayId(): ?string
    {
        return $this->payId;
    }

    public function setPayId(string $payId): self
    {
        $this->payId = $payId;

        return $this;
    }
}
