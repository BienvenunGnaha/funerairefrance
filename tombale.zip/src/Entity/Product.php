<?php

namespace App\Entity;

use App\Repository\ProductRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProductRepository::class)
 */
class Product
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="boolean")
     */
    private $status;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="boolean")
     */
    private $allowedCondition;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $color;

    /**
     * @ORM\Column(type="json")
     */
    private $size = [];

    /**
     * @ORM\Column(type="boolean")
     */
    private $isPriceOff;

    /**
     * @ORM\Column(type="integer")
     */
    private $cprice;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $pprice;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(type="integer")
     */
    private $view;

    /**
     * @ORM\Column(type="boolean")
     */
    private $allowSeo;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $metaKeys;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $title;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $metaDesc;

    /**
     * @ORM\ManyToOne(targetEntity=Category::class, inversedBy="products")
     */
    private $catId;

    /**
     * @ORM\ManyToOne(targetEntity=Subcategory::class, inversedBy="products")
     */
    private $subCatId;


    public function getId(): ?int
    {
        return $this->id;
    }



    public function getStatus(): ?bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getAllowedCondition(): ?bool
    {
        return $this->allowedCondition;
    }

    public function setAllowedCondition(bool $allowedCondition): self
    {
        $this->allowedCondition = $allowedCondition;

        return $this;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    public function setColor(string $color): self
    {
        $this->color = $color;

        return $this;
    }

    public function getSize(): ?array
    {
        return $this->size;
    }

    public function setSize(array $size): self
    {
        $this->size = $size;

        return $this;
    }

    public function getIsPriceOff(): ?bool
    {
        return $this->isPriceOff;
    }

    public function setIsPriceOff(bool $isPriceOff): self
    {
        $this->isPriceOff = $isPriceOff;

        return $this;
    }

    public function getCprice(): ?int
    {
        return $this->cprice;
    }

    public function setCprice(int $cprice): self
    {
        $this->cprice = $cprice;

        return $this;
    }

    public function getPprice(): ?int
    {
        return $this->pprice;
    }

    public function setPprice(?int $pprice): self
    {
        $this->pprice = $pprice;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getView(): ?int
    {
        return $this->view;
    }

    public function setView(int $view): self
    {
        $this->view = $view;

        return $this;
    }

    public function getAllowSeo(): ?bool
    {
        return $this->allowSeo;
    }

    public function setAllowSeo(bool $allowSeo): self
    {
        $this->allowSeo = $allowSeo;

        return $this;
    }

    public function getMetaKeys(): ?string
    {
        return $this->metaKeys;
    }

    public function setMetaKeys(?string $metaKeys): self
    {
        $this->metaKeys = $metaKeys;

        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function getMetaDesc(): ?string
    {
        return $this->metaDesc;
    }

    public function setMetaDesc(?string $metaDesc): self
    {
        $this->metaDesc = $metaDesc;

        return $this;
    }

    /**
     * @ORM\PrePersist
     */
    public function setContentValue(){
        $content  = $this->getDescription();
        $texte = preg_match_all('#src="(data:image/.+)"#i', $content, $text);
        $targets = [];
        $content_to_replace = [];
        if(isset($text[1]) && is_array($text[1])){
            if($lenght = count($text[1]) > 0){
                for($i = 0; $i < $lenght; $i++){
                    $src = explode(',', $text[1][$i]);
                    if(count($src) > 1){
                        $target = '..//../public/uploads/blog/images'.(new DateTime)->getTimestamp().'.'.explode(';', explode('/', $src[0])[1])[0];
                        try {
                            if($ifp = fopen($target, 'wb')){
                                if (fwrite( $ifp, base64_decode( $src[1] ) )){
                                    $replace = explode('public', $target)[1];
                                    $content_replace = 'src="'.$replace.'"';
                                    $targets[] = $content_replace;
                                    $content_to_replace[] = $text[0][$i];
                                }
                            }

                            // clean up the file resource
                            fclose( $ifp );

                        }catch (Exception $exception){

                        }
                    }

                }
                $t_len = count($targets);
                $c_len = count($content_to_replace);
                if ($t_len !== 0 && $c_len !== 0 && $t_len === $c_len){
                    $content = str_replace($content_to_replace, $targets, $content);
                    $this->description = $content;
                }
            }


        }
    }

    public function getCatId(): ?Category
    {
        return $this->catId;
    }

    public function setCatId(?Category $catId): self
    {
        $this->catId = $catId;

        return $this;
    }

    public function getSubCatId(): ?Subcategory
    {
        return $this->subCatId;
    }

    public function setSubCatId(?Subcategory $subCatId): self
    {
        $this->subCatId = $subCatId;

        return $this;
    }


}
