<?php

namespace App\EventSubscriber;

use App\Entity\Blog;
use App\Entity\Product;
use App\Services\TextareaImage;
use Symfony\Component\EventDispatcher\GenericEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\TerminateEvent;

class ProductSubscriber implements EventSubscriberInterface
{
    public function onKernelTerminate(TerminateEvent $event)
    {
        // ...
    }

    public function setProductDescription(GenericEvent $event)
    {
        $entity = $event->getSubject();

        if (!($entity instanceof Product)) {
            return;
        }


        $content  = $entity->getDescription();
        $t_image = new TextareaImage();
        $content = $t_image->searchReplaceImage64($content, 'product');
        if($content) $entity->setDescription($content);
        $event['entity'] = $entity;
    }

    public static function getSubscribedEvents()
    {
        return [
            'kernel.terminate' => 'onKernelTerminate',
            'easy_admin.pre_update' => 'setProductDescription',
            'easy_admin.pre_persist' => 'setProductDescription',
        ];
    }


}
